// import {test,expect} from '@playwright/test';
import { log } from '../pages/loginpage.js';
import { getTestData } from '../utility/testdata.js';
import { test } from '../customfixture/loginfixture.js';

test('lgoin using pom', async ({ page }) => {

    const lp = new log(page);
    await lp.navigation();
    await lp.loginjson();
    const val = getTestData('TC002');
    if (val.expectedResult === 'success') {
        await lp.verify_url();
    }
    else if (val.expectedResult = "Epic sadface") {
        await lp.errorMessage(val.expectedResult);
    }

})

test('using fixtures', { tag: '@smoke' }, async ({ loginfix }) => {
    await loginfix.navigation();
    await loginfix.loginjson();
    const val = getTestData('Tc001');
    if (val.expectedResult === 'success') {
        await lp.verify_url();
    }
    else if (val.expectedResult = "Epic sadface") {
        await lp.errorMessage(val.expectedResult);
    }



})