import { test, expect } from '../../customfixture/apiClient.js';
import { authservice } from '../../api/service/authService.js';
import { BookingService } from '../../api/service/bookingService.js';

test('method sequential chaining', async ({ apifix }) => {
    const authService = new authservice(apifix);
    const bookingService = new BookingService(apifix);

    let bookingId;
    let token;


    const originalBooking = {
        firstname: 'Harish',
        lastname: 'Baskar',
        totalprice: 1500,
        depositpaid: true,
        bookingdates: {
            checkin: '2026-11-01',
            checkout: '2026-11-05'
        },
        additionalneeds: 'Breakfast'
    };

    // 1. AUTHENTICATION
    const authResponse = await authService.generate_token('admin', 'password123');
    expect(authResponse.status()).toBe(200);
    const authBody = await authResponse.json();
    token = authBody.token;

    //2. create method
    const createResponse = await bookingService.createBooking(originalBooking);
    expect(createResponse.status()).toBe(200);
    const createdBooking = await createResponse.json();
    bookingId = createdBooking.bookingid;
    expect(createdBooking.booking.firstname).toBe(originalBooking.firstname);

    // 3. GET BOOKING USING THE EXTRACTED ID
    const getResponse = await bookingService.getBooking(bookingId);
    expect(getResponse.status()).toBe(200);
    const fetchedBooking = await getResponse.json();
    expect(fetchedBooking.firstname).toBe('Harish');
    expect(fetchedBooking.lastname).toBe('Baskar');

    // 4. partial  UPDATE — PUT
    const patchResponse =
        await bookingService.partialUpdateBooking(bookingId,
            { additionalneeds: 'Lunch' },
            token
        );

    expect(patchResponse.status()).toBe(200);

    // 5. DELETE BOOKING
    const deleteResponse =
        await bookingService.deleteBooking(bookingId, token);

    expect(deleteResponse.status()).toBe(201);

    // 6. VERIFY DELETION
    const finalGetResponse =
        await bookingService.getBooking(bookingId);

    expect(finalGetResponse.status()).toBe(404);

    console.log('API E2E flow completed successfully.');






})